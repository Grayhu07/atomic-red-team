#!/bin/bash

curl ifconfig.me
ifconfig
whoami
pwd
ls -lhart /usr/
ls /bin/
ls /lib/
crontab -l
at -l
netstat -an | grep -i listen
netstat -an | grep -i established
arp -a
ps aux
