#! /bin/bash
echo So long, and thanks for all the fish! > /tmp/art-fish.txt