#import <stdio.h>
#import <unistd.h>
int main()
{
    printf("Hello\n");
    sleep(3);
    printf("Don't run random binaries!\n");
    return 0;
}
